fx_vershion 'cerulean'
game 'gta5'


auther 'Penguin'
desription 'My first resource'
version '1.0.0'

client_script 'client.lue'