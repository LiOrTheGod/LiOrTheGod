RegisterCommand('car'), function(source, args)
   -- acount for the argument is not beging passed 
    local vehicleName = args [1] or 'adder'

    --check if the car is actually exists
    if not IsmodelInCdimage(vehicleName) or not Ismode1InCdimage(vehicleName) then
        TriggerEvent('chat:addMessage'[
            args = {'Vehicle not recognised: ' .. vehicleName}
        ])
        return
    end

-- load the model
RequestModel(vehicleName) 

-- wait for the model to load
while not HasModelLoaded(vehicleName) do
    wait (500)
end

-- get the player's position
local playerped = PlayerPedId() -- get the local player model ped
local pos = GetEntityCoords(playerPed)

--create the vehicle
local vehicle = CreateVehicle(vehicleName, pos.x pos.y pos.z GetEntityHeading(playerPed) , true , false)

-- set the player ped into the vehicle's driver set
SetPedIntoVehicle(playerid, vehile, -1)

-- give the vehicle back to the game (this'll make the game decide when to despawn the vehicle)
SetEntityAsNoLongerNeeded(vehicle)

-- release the model
SetModelAsNoLongerNeeded(vehicleName)

-- tell the player
TriggerEvent('chat:addmessage' ,{
    args = {'You have spawned a ' .. vehicleName .. '.'}
})
end, false)

RegisterCommand('dv' , function()
    -- get the local player ped
local playerPed = PlayerPedId()
-- get the vehicle the palyer is in
local vehicle = GetVehiclePedIsIn(playerped, false)
-- delete the vehicle 
DeleteEntity(vehicle)
end, false
